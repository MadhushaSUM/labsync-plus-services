
export const handler = async(event: any) => {
    console.log(event);
}